
var krms_config ={	
	'ApiUrl' : "http://fellybellyapp.com/mobileapp/api",
	'DialogDefaultTitle' : "fellybelly",
	'pushNotificationSenderid' : "567963922042",
	'facebookAppId' : "1287995804625555",
	'APIHasKey' : "fed7b441b349bae8f146711fbd215e90"
};